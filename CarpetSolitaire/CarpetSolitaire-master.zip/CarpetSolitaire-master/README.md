# CarpetSolitaire
The game of Carpet Solitire, used for COSC 3011. Project 1. 

Note. All this code is way out of date and does not reflect my current skill level. I'm just holding it here to reference a future project.
